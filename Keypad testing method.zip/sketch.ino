void setup() {
  volatile long i,j;
  volatile char*dirc,*dirk,*dirf,*dira,x;
  volatile char*outc,*ink,*outf,*outa;
  dirc=0x27;dirf=0x30;dirk=0x107;dira=0x21;
  outc=0x28;outf=0x31;ink=0x106;outa=0x22;
  *dirf=0x0f;*dirk=0x00;*dira=0x0f;
  while(1){
    for(i=0;i<4;i++){
      *outf=1<<i;
      *outa=*ink;
      if(*ink!=0){
        *outc=1<<i;
        for(j=0;j<500000;j++);
        *outc=0;
      }
    }
  }
}

void loop() {
  // put your main code here, to run repeatedly:

}
