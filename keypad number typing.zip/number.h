int number(long x){
  long a;
  volatile long i;
  if(x==0){
    a=0x3f;
  }
  else if(x==1){
    a=0x06;
  }
  else if(x==2){
    a=0x5b;
  }
  else if(x==3){
    a=0x4f;
  }
  else if(x==4){
    a=0x66;
  }
  else if(x==5){
    a=0x6d;
  }
  else if(x==6){
    a=0x7d;
  }
  else if(x==7){
    a=0x07;
  }
  else if(x==8){
    a=0x7f;
  }
  else{
    a=0x6f;
  }
  return a;
}