#include "number.h"
#include "keypad.h"
void setup(){
  volatile char*dira,*dirf,*dirk;
  dira=0x21;dirf=0x30;dirk=0x107;
  *dira=0xff;*dirf=0x0f;*dirk=0xf0;
}
void loop(){
  scan();
}

